g++ -std=c++11 -O2 -g -Wall -o main calibration.cpp -I${ROOTSYS}/include $(root-config --glibs)
