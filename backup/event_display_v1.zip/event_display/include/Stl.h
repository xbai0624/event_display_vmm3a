

// -*- c++ -*- 

//#ifndef __CLING__ 
#include <vector> 
//#include <string> 
//#include <map> 
//#endif 
using namespace std;
namespace Dummy {   
    vector<vector<int> > vvi;   
    vector<vector<float> > vvf; 
}


