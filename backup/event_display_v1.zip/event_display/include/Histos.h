#ifndef HISTOS_H
#define HISTOS_H

#include <vector>
#include <unordered_map>
#include <TH1F.h>
#include <TH2F.h>

namespace histos
{
    extern int nVMM;

    extern std::vector<TH1F*> hStripAdcDistributionPlaneX;
    extern std::vector<TH1F*> hStripAdcDistributionPlaneY;
    extern std::vector<TH1F*> hStripIndexDistributionPlaneX;
    extern std::vector<TH1F*> hStripIndexDistributionPlaneY;
    extern std::vector<TH1F*> hClusterAdcDistributionPlaneX;
    extern std::vector<TH1F*> hClusterAdcDistributionPlaneY;
    extern std::vector<TH1F*> hClusterPosDistributionPlaneX;
    extern std::vector<TH1F*> hClusterPosDistributionPlaneY;
    extern std::vector<TH1F*> hClusterSizeDistributionPlaneX;
    extern std::vector<TH1F*> hClusterSizeDistributionPlaneY;

    extern std::vector<TH2F*> hCluster2DDistribution;

    extern std::unordered_map<int, std::vector<TH1F*>> mAdcDistributionPerStrip;
    extern std::vector<TH2F*> mAdc2DDistribution;
    extern std::unordered_map<int, std::vector<TH1F*>> mTimingDistributionPerStrip;
    extern std::vector<TH2F*> mTiming2DDistribution;

    void init();

    template<typename T>
        void __reset_vector_histos(std::vector<T> &vecs) {
            for(auto &i: vecs)
                i -> Reset("ICESM");
        }

    void reset();
};

#endif
