#ifndef CLUSTER_H
#define CLUSTER_H

#include <vector>
#include <ostream>

struct Cluster 
{
    Cluster();
    ~Cluster();

    int max_charge();
    int sum_charge();
    int size();
    float pos();

    std::vector<int> strips;
    std::vector<int> charge;
    std::vector<int> timing;
};

std::ostream& operator<<(std::ostream &os, const Cluster &c);

#endif
