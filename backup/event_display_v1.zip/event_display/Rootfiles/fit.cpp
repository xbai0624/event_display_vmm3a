{
    gStyle -> SetOptFit(111);

    /*
    // 3.0 mV/fC
    TFile *f1 = new TFile("results_0366.root");
    TH1F* h1 = (TH1F*) f1 -> Get("hClusterAdcDistributionPlaneX");
    h1 -> Fit("landau", "", "", 350, 1000);
    TCanvas *c1 = new TCanvas("c1", "c1", 800, 600);
    c1 -> cd();
    h1 -> Draw();
    c1 -> Update();
    */

    // 4.5 mV/fC
    TFile *f2 = new TFile("results_0367.root");
    TH1F* h2 = (TH1F*) f2 -> Get("hClusterAdcDistributionPlaneX");
    h2 -> Fit("landau", "", "", 320, 1800);
    TCanvas *c2 = new TCanvas("c2", "c2", 800, 600);
    c2 -> cd();
    h2 -> Draw();
    c2 -> Update();
}
