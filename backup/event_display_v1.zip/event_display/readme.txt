
1) source build_stl.sh to generate dictionaries

2) source set_env.sh to setup enviroments
