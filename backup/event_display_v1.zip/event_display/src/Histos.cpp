#include "Histos.h"

namespace histos
{
    int nVMM = 1;

    std::vector<TH1F*> hStripAdcDistributionPlaneX;
    std::vector<TH1F*> hStripAdcDistributionPlaneY;
    std::vector<TH1F*> hStripIndexDistributionPlaneX;
    std::vector<TH1F*> hStripIndexDistributionPlaneY;
    std::vector<TH1F*> hClusterAdcDistributionPlaneX;
    std::vector<TH1F*> hClusterAdcDistributionPlaneY;
    std::vector<TH1F*> hClusterPosDistributionPlaneX;
    std::vector<TH1F*> hClusterPosDistributionPlaneY;
    std::vector<TH1F*> hClusterSizeDistributionPlaneX;
    std::vector<TH1F*> hClusterSizeDistributionPlaneY;

    std::vector<TH2F*> hCluster2DDistribution;

    std::unordered_map<int, std::vector<TH1F*>> mAdcDistributionPerStrip;
    std::vector<TH2F*> mAdc2DDistribution;
    std::unordered_map<int, std::vector<TH1F*>> mTimingDistributionPerStrip;
    std::vector<TH2F*> mTiming2DDistribution;

    // hard-coded for now
    void init() 
    {
        // strip adc distribution
        hStripAdcDistributionPlaneX.push_back(
                new TH1F("hStripAdcDistributionPlaneX", "X Adc Distribution", 1000, 0, 1000)
                );
        hStripAdcDistributionPlaneY.push_back(
                new TH1F("hStripAdcDistributionPlaneY", "Y Adc Distribution", 1000, 0, 1000)
                );

        // strip index distribution
        hStripIndexDistributionPlaneX.push_back(
                new TH1F("hStripIndexDistributionPlaneX", "X channel index",
                    64, 0, 64)
                );
        hStripIndexDistributionPlaneY.push_back(
                new TH1F("hStripIndexDistributionPlaneY", "Y channel index",
                    64, 0, 64)
                );

        // cluster adc distribution
        hClusterAdcDistributionPlaneX.push_back(
                new TH1F("hClusterAdcDistributionPlaneX", "X cluster Adc distribution", 300, 0, 3000)
                );
        hClusterAdcDistributionPlaneY.push_back(
                new TH1F("hClusterAdcDistributionPlaneY", "Y cluster Adc distribution", 300, 0, 3000)
                );

        // cluster pos distribution
        hClusterPosDistributionPlaneX.push_back(
                new TH1F("hClusterPosDistributionPlaneX", "x cluster pos distribution", 100, 0, 100)
                );
        hClusterPosDistributionPlaneY.push_back(
                new TH1F("hClusterPosDistributionPlaneY", "y cluster pos distribution", 100, 0, 100)
                );

        // cluster size distribution
        hClusterSizeDistributionPlaneX.push_back(
                new TH1F("hClusterSizeDistributionPlaneX", "x cluster size distribution", 20, -0.5, 19.5)
                );
        hClusterSizeDistributionPlaneY.push_back(
                new TH1F("hClusterSizeDistributionPlaneY", "y cluster size distribution", 20, -0.5, 19.5)
                );

        // cluster 2d distribution
        hCluster2DDistribution.push_back(
                new TH2F("hCluster2DDistribution", "cluser 2d map", 100, 0, 100, 100, 0, 100)
                );

        // strip adc distribution
        for(int vmm=0; vmm<nVMM; vmm++)
        {
            for(int i=0; i<64; i++) {
                mAdcDistributionPerStrip[vmm].push_back(
                        new TH1F(Form("hADCDistributioinVMM%d_Ch%d", vmm, i),
                            Form("hADCDistributioinVMM%d_Ch%d", vmm, i),
                            1000, 0, 2000)
                        );
                mTimingDistributionPerStrip[vmm].push_back(
                        new TH1F(Form("hTimingDistributioinVMM%d_Ch%d", vmm, i),
                            Form("hTimingDistributioinVMM%d_Ch%d", vmm, i),
                            800, 0, 800)
                        );
            }

            mAdc2DDistribution.push_back(
                    new TH2F(Form("h2DAdcVMM%d", vmm), Form("h2DAdcVMM%d", vmm),
                        64, 0, 64, 1000, 0, 2000)
                    );
            mTiming2DDistribution.push_back(
                    new TH2F(Form("h2DTimingVMM%d", vmm), Form("h2DTimingVMM%d", vmm),
                        64, 0, 64, 800, 0, 800)
                    );
        }

        // axis title
        for(auto &i: hStripAdcDistributionPlaneX) {
            i->GetXaxis() -> SetTitle("strip ADC");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hStripAdcDistributionPlaneY) {
            i->GetXaxis() -> SetTitle("strip ADC");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hStripIndexDistributionPlaneX) {
            i->GetXaxis() -> SetTitle("strip Index");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hStripIndexDistributionPlaneY) {
            i->GetXaxis() -> SetTitle("strip Index");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hClusterAdcDistributionPlaneX) {
            i->GetXaxis() -> SetTitle("cluster ADC");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hClusterAdcDistributionPlaneY) {
            i->GetXaxis() -> SetTitle("cluster ADC");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hClusterPosDistributionPlaneX) {
            i->GetXaxis() -> SetTitle("cluster Position [mm]");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hClusterPosDistributionPlaneY) {
            i->GetXaxis() -> SetTitle("cluster Position [mm]");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hClusterSizeDistributionPlaneX) {
            i->GetXaxis() -> SetTitle("cluster size");
            i->GetYaxis() -> SetTitle("counts");
        }
        for(auto &i: hClusterSizeDistributionPlaneY) {
            i->GetXaxis() -> SetTitle("cluster size");
            i->GetYaxis() -> SetTitle("counts");
        }
 
        for(auto &i: mAdc2DDistribution){
            i->GetXaxis() -> SetTitle("VMM channel");
            i->GetYaxis() -> SetTitle("ADC counts");
        }
        for(auto &i: mTiming2DDistribution){
            i->GetXaxis() -> SetTitle("VMM channel");
            i->GetYaxis() -> SetTitle("Timing counts");
        }
    }

    void reset()
    {
        __reset_vector_histos<TH1F*>(hStripAdcDistributionPlaneX);
        __reset_vector_histos<TH1F*>(hStripAdcDistributionPlaneY);
        __reset_vector_histos<TH1F*>(hStripIndexDistributionPlaneX);
        __reset_vector_histos<TH1F*>(hStripIndexDistributionPlaneY);
        __reset_vector_histos<TH1F*>(hClusterAdcDistributionPlaneX);
        __reset_vector_histos<TH1F*>(hClusterAdcDistributionPlaneY);
        __reset_vector_histos<TH1F*>(hClusterPosDistributionPlaneX);
        __reset_vector_histos<TH1F*>(hClusterPosDistributionPlaneY);
        __reset_vector_histos<TH1F*>(hClusterSizeDistributionPlaneX);
        __reset_vector_histos<TH1F*>(hClusterSizeDistributionPlaneY);
        __reset_vector_histos<TH2F*>(hCluster2DDistribution);

        for(auto &i: mAdcDistributionPerStrip)
            __reset_vector_histos<TH1F*>(i.second);

        __reset_vector_histos<TH2F*>(mAdc2DDistribution);

        for(auto &i: mTimingDistributionPerStrip)
            __reset_vector_histos<TH1F*>(i.second);

        __reset_vector_histos<TH2F*>(mTiming2DDistribution);
    }
};
