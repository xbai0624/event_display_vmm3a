#include "Cluster.h"
#include <iomanip>

Cluster::Cluster()
{
    strips.clear();
}

Cluster::~Cluster()
{
}

int Cluster::size()
{
    return (int) strips.size();
}

int Cluster::max_charge()
{
    if(strips.size() <= 0)
        return -9999;

    int c = charge[0];
    for(size_t i=0; i<charge.size(); ++i)
    {
        if(c < charge[i])
            c = charge[i];
    }

    return c;
}

int Cluster::sum_charge()
{
    int s = 0;
    for(auto &i: charge)
        s += i;
    return s;
}

float Cluster::pos()
{
    if(size() <= 0)
        return -99999.;

    float s = (float)sum_charge();

    const float pitch = 0.4;

    float tmp = 0;
    for(int i=0; i<size(); ++i)
    {
        tmp += strips[i] * pitch * charge[i];
    }
    tmp /= s;

    return tmp;
}

std::ostream & operator<<(std::ostream &os, const Cluster &c)
{
    os<<"strip: ";
    for(auto &i: c.strips)
        os<<std::setfill(' ')<<std::setw(6)<<i;
    os<<std::endl;
    os<<"adc: ";
    for(auto &i: c.charge)
        os<<std::setfill(' ')<<std::setw(6)<<i;
    os<<std::endl;
    os<<"timing: ";
    for(auto &i: c.timing)
        os<<std::setfill(' ')<<std::setw(6)<<i;
    os<<std::endl;
    return os;
}
